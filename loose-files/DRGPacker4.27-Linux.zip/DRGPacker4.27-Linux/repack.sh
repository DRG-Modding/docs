#!/bin/sh 

print_usage()
{
  echo "Usage:" >&2
  echo "  $0 INPUT_FOLDER    Packs the content of INPUT_FOLDER in the current directory" >&2
  echo ""
  echo "Folder will be packed in .pak file with the same name."
}


if [ "$#" -ne 1 ]; then
  print_usage
  exit 1
fi

if ! [ -d "$1" ]; then
  echo "$1 is not a directory.\n"
  print_usage
  exit 1
fi


# Remove trailing / if any
NAME=${1%*/}

# Retrieve the file name from the given path
NAME=${NAME##/*/}

SOURCE_PATH=$1

# Convert to absolute path if necessary
case $NAME in
  /*) ;;
  ~*) ;;
  *) SOURCE_PATH="$(pwd)/$NAME" ;;
esac



echo "\"$(pwd)/$NAME/**\"" "../../../FSD/**" > autogen.txt
./UnrealPak/Engine/Binaries/Linux/UnrealPak "$(pwd)/$NAME.pak" -create="$(pwd)/autogen.txt" -platform="Windows" -compress
