#!/bin/sh 

print_usage()
{
  echo "Usage:" >&2
  echo "  $0 INPUT_PAK    Unpack the given file in the current directory." >&2
  echo ""
  echo "Files will be extracted in a folder with the same name as the pak file."
}

if [ "$#" -ne 1 ]; then
  print_usage
  exit 1
fi

if ! [ -f "$1" ]; then
  echo "$1 is not a file.\n"
  print_usage
  exit 1
fi

# Check if the given file is a .pak
if ! [ "${1##*.}" = "pak" ]; then
  echo "$1 is not a .pak file.\n"
  print_usage
  exit 1
fi

# Retrieve the file name from the given path
NAME_WITH_EXT=${1##/*/}
NAME=${NAME_WITH_EXT%*.pak}

# Execute the unpack command
./UnrealPak/Engine/Binaries/Linux/UnrealPak "$1" -platform="Windows" -extract "$(pwd)/$NAME"
