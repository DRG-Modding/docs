Thanks for atenfyr for originally showing us how to produce these standalone packers!

## How to unpack

Paste the FSD-WindowsNoEditor.pak into the folder. Then simply run the script `unpack.sh FSD-WindowsNoEditor.pak`. The resources will be extracted in the current directory in a folder with the same name as the `.pak` file.

Run `unpack.sh` without arguments to see the help.

## How to repack

Make a folder with the name of your mod. Then put your Content folder (plus asset registry if you're doing BP modding) inside of it. Then run the `repack.sh` script with your folder as argument. The generated `.pak` file will be generated next to the script.

Example: `./repack.sh My_Mod_P`

Run `repack.sh` without arguments to see the help.

