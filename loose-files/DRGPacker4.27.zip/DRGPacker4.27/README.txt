Thanks for atenfyr for originally showing us how to produce these standalone packers!

How to unpack:
Paste the FSD-WindowsNoEditor.pak into the folder. Then simply drag and drop it onto _Unpack.bat.

How to repack:
Make a folder called anything, input is fine. Then put your Content folder (plus asset registry if you're doing BP modding) inside of it. Then drag and drop the folder onto _Repack.bat.